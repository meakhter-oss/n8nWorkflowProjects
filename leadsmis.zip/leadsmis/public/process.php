<?php
if(isset($_REQUEST['XXX'])){
    $websites=$_REQUEST['XXX'];
    $email = getEmailsFromWebsite($websites);
    echo($email);
    exit();
}else{
    echo "Wrong key";
}

function getEmailsFromWebsite($url) {
    // Fetch the HTML content
    $html = @file_get_contents($url);

    if (!$html) {
        return ["error" => "Unable to fetch website content."];
    }

    // Regular expression to match emails
    preg_match_all(
        '/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/',
        $html,
        $matches
    );

    // Remove duplicates
    $emails = array_unique($matches[0]);
    if(count($emails)>0){
        return $emails[0];
    }else{
        return "";
    }
    
}
?>
