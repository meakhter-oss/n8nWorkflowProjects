# Welcome to your project

Follow these steps:

# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```
## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?
. install database script to you supbase database  from supbase- migration folder
- Please set the supbase credentials in .env file.
- build the runable code using npm run build command. 
- Upload files and folder in (dist) folder to hosting account using ftp or cpanel. 
- Upload workflows from workflows folder and set required credentials. 
- put the key(mentiond in workflow 3) in process.php file present in public folder. 
- upload this file to your root folder of application installed on hsoting server.
