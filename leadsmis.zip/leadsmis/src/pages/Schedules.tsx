import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, Search, Building2, Loader2, ChevronLeft, ChevronRight } from "lucide-react";

interface Category {
  id: string;
  name: string;
}

interface Schedule {
  id: string;
  name: string;
  message: string;
  category_id: string | null;
  status: string | null;
  stype: string | null;
  created_at: string;
  categories?: Category | null;
}

const ITEMS_PER_PAGE = 10;

export default function Schedules() {
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedSchedule, setSelectedSchedule] = useState<Schedule | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: "",
    message: "",
    category_id: "",
    status: "Pending",
    stype: "",
  });

  async function fetchSchedules() {
    setIsLoading(true);
    
    let query = supabase
    .from("schedules")
        .select("*, categories(id, name)", { count: "exact" });

        if (searchQuery) {
            query = query.or(`name.ilike.%${searchQuery}%,status.ilike.%${searchQuery}%`);
        }

    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE - 1;

    const { data, error, count } = await query
      .order("created_at", { ascending: false })
      .range(start, end);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to fetch schedules",
        variant: "destructive",
      });
    } else {
      setSchedules(data || []);
      setTotalCount(count || 0);
    }
    setIsLoading(false);
  }

  async function fetchCategories() {
    const { data } = await supabase.from("categories").select("*").order("name");
    setCategories(data || []);
  }

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    fetchSchedules();
  }, [currentPage, searchQuery]);

  const handleOpenDialog = (schedule?: Schedule) => {
    if (schedule) {
      setSelectedSchedule(schedule);
      setFormData({
        name: schedule.name,
        message: schedule.message,
        category_id: schedule.category_id || "",
        status: schedule.status || "",
        stype: schedule.stype || "",
      });
    } else {
      setSelectedSchedule(null);
      setFormData({
        name: "",
        message: "",
        category_id: "",
        status: "",
        stype: "",
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Schedule name is required",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);

    const scheduleData = {
      name: formData.name.trim(),
      message: formData.message.trim(),
      category_id: formData.category_id || null,
      status: formData.status.trim() || null,
      stype: formData.stype.trim() || null,
    };

    if (selectedSchedule) {
      const { error } = await supabase
        .from("schedules")
        .update(scheduleData)
        .eq("id", selectedSchedule.id);

      if (error) {
        toast({
          title: "Error",
          description: "Failed to update schedule",
          variant: "destructive",
        });
      } else {
        toast({ title: "Success", description: "Schedule updated successfully" });
        setIsDialogOpen(false);
        fetchSchedules();
      }
    } else {
      const { error } = await supabase.from("schedules").insert(scheduleData);

      if (error) {
        toast({
          title: "Error",
          description: "Failed to create schedule",
          variant: "destructive",
        });
      } else {
        toast({ title: "Success", description: "Schedule created successfully" });
        setIsDialogOpen(false);
        fetchSchedules();
      }
    }

    setIsSaving(false);
  };

  const handleDelete = async () => {
    if (!selectedSchedule) return;

    const { error } = await supabase
      .from("schedules")
      .delete()
      .eq("id", selectedSchedule.id);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to delete schedule",
        variant: "destructive",
      });
    } else {
      toast({ title: "Success", description: "Schedule deleted successfully" });
      setIsDeleteDialogOpen(false);
      setSelectedSchedule(null);
      fetchSchedules();
    }
  };

  const totalPages = Math.ceil(totalCount / ITEMS_PER_PAGE);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold">Schedules</h1>
            <p className="mt-1 text-muted-foreground">
              Manage your schedule listings
            </p>
          </div>
          <Button onClick={() => handleOpenDialog()}>
            <Plus className="mr-2 h-4 w-4" />
            Add Schedule
          </Button>
        </div>

        <Card className="border-border/50">
          <CardHeader className="pb-4">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                All Schedules ({totalCount})
              </CardTitle>
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search schedules..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex h-64 items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : schedules.length === 0 ? (
              <div className="flex h-64 flex-col items-center justify-center text-muted-foreground">
                <Building2 className="mb-4 h-12 w-12" />
                <p className="text-lg font-medium">No schedules found</p>
                <p className="text-sm">Add your first schedule to get started</p>
              </div>
            ) : (
              <>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead className="hidden lg:table-cell">Stype</TableHead>
                        <TableHead className="hidden lg:table-cell">Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {schedules.map((schedule) => (
                        <TableRow key={schedule.id} className="animate-fade-in">
                          <TableCell className="font-medium">{schedule.name}</TableCell>
                          <TableCell>
                            {schedule.categories?.name || (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            {schedule.stype || <span className="text-muted-foreground">—</span>}
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            {schedule.status || <span className="text-muted-foreground">—</span>}
                          </TableCell>
                          
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleOpenDialog(schedule)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setSelectedSchedule(schedule);
                                  setIsDeleteDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="mt-4 flex items-center justify-between">
                    <p className="text-sm text-muted-foreground">
                      Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{" "}
                      {Math.min(currentPage * ITEMS_PER_PAGE, totalCount)} of {totalCount}
                    </p>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Add/Edit Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {selectedSchedule ? "Edit Schedule" : "Add Schedule"}
              </DialogTitle>
              <DialogDescription>
                {selectedSchedule
                  ? "Update the schedule information below"
                  : "Fill in the details to add a new schedule"}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Schedule Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="Enter schedule name"
                />
              </div>
              <div className="space-y-2">
              <Label htmlFor="message">Schedule Message *</Label>
                <textarea
                id="message"
                value={formData.message}
                onChange={(e) =>
                    setFormData({ ...formData, message: e.target.value })
                }
                placeholder="Enter schedule Message"
                rows={5} 
                className="mt-1 block w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-primary"
                />



              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category_id}
                  onValueChange={(value) =>
                    setFormData({ ...formData, category_id: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
             
             <div className="space-y-2">
                <Label htmlFor="stype">Type</Label>
                <Select
                  value={formData.stype}
                  onValueChange={(value) =>
                    setFormData({ ...formData, stype: value })
                  }
                >
                <SelectTrigger>
                    <SelectValue placeholder="Schedule Type" />
                </SelectTrigger>
                  <SelectContent>
                    <SelectItem key="Email" value="Email">
                        Email
                    </SelectItem>
                    <SelectItem key="Whatsapp" value="Whatsapp">
                        Whatsapp
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
        
              
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Input
                  id="status"
                  value={formData.status}
                  onChange={(e) =>
                    setFormData({ ...formData, status: e.target.value })
                  }
                  placeholder="Pending"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={isSaving}>
                {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {selectedSchedule ? "Update" : "Create"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Dialog */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Schedule</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{selectedSchedule?.name}"? This action
                cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </DashboardLayout>
  );
}
