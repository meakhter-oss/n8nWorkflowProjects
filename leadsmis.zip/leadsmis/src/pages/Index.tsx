import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Building2, ArrowRight, Shield, Zap, MessageSquare } from "lucide-react";

export default function Index() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && user) {
      navigate("/dashboard");
    }
  }, [user, isLoading, navigate]);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl gradient-primary">
              <Building2 className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-semibold">AdminPanel</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate("/auth")}>
              Sign In
            </Button>
            <Button onClick={() => navigate("/auth")}>
              Get Started
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <main className="flex-1">
        <section className="container mx-auto px-4 py-20 text-center">
          <div className="mx-auto max-w-3xl animate-fade-in">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border bg-card px-4 py-2 text-sm">
              <Shield className="h-4 w-4 text-primary" />
              Secure Admin Dashboard
            </div>
            <h1 className="mb-6 text-4xl font-bold leading-tight md:text-5xl lg:text-6xl">
              Manage your leads
              <span className="block gradient-primary bg-clip-text text-white p-4 m-2">
                with confidence
              </span>
            </h1>
            <p className="mx-auto mb-10 max-w-xl text-lg text-muted-foreground">
              A powerful admin panel to manage leads from google map.
            </p>
            <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button size="lg" onClick={() => navigate("/auth")}>
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="container mx-auto px-4 pb-20">
          <div className="grid gap-6 md:grid-cols-3">
            <div className="animate-slide-up rounded-2xl border bg-card p-6" style={{ animationDelay: "100ms" }}>
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Company Management</h3>
              <p className="text-muted-foreground">
                Easily add, edit, and organize your company listings with categories and detailed information.
              </p>
            </div>

            <div className="animate-slide-up rounded-2xl border bg-card p-6" style={{ animationDelay: "200ms" }}>
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-success/10">
                <Shield className="h-6 w-6 text-success" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Secure Authentication</h3>
              <p className="text-muted-foreground">
                Role-based access control with secure admin authentication and profile management.
              </p>
            </div>

            <div className="animate-slide-up rounded-2xl border bg-card p-6" style={{ animationDelay: "300ms" }}>
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-warning/10">
                <Zap className="h-6 w-6 text-warning" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Webhook Integration</h3>
              <p className="text-muted-foreground">
                Connect with n8n workflows to automate your processes and handle queries efficiently.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card/50">
        <div className="container mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          © 2024 AdminPanel. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
