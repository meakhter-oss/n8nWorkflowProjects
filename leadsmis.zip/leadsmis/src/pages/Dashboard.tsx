import { useEffect, useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { Building2, Users, MessageSquare, FolderOpen, TrendingUp, ArrowUpRight } from "lucide-react";

interface Stats {
  companies: number;
  admins: number;
  queries: number;
  categories: number;
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats>({
    companies: 0,
    admins: 0,
    queries: 0,
    categories: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchStats() {
      const [companiesRes, adminsRes, queriesRes, categoriesRes] = await Promise.all([
        supabase.from("companies").select("*", { count: "exact", head: true }),
        supabase.from("profiles").select("*", { count: "exact", head: true }),
        supabase.from("queries").select("*", { count: "exact", head: true }),
        supabase.from("categories").select("*", { count: "exact", head: true }),
      ]);

      setStats({
        companies: companiesRes.count || 0,
        admins: adminsRes.count || 0,
        queries: queriesRes.count || 0,
        categories: categoriesRes.count || 0,
      });
      setIsLoading(false);
    }

    fetchStats();
  }, []);

  const statCards = [
    {
      title: "Total Companies",
      value: stats.companies,
      icon: Building2,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Total Admins",
      value: stats.admins,
      icon: Users,
      color: "text-success",
      bgColor: "bg-success/10",
    },
    {
      title: "Categories",
      value: stats.categories,
      icon: FolderOpen,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="mt-1 text-muted-foreground">
            Overview of your admin panel statistics
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {statCards.map((card, index) => (
            <Card
              key={card.title}
              className="animate-slide-up border-border/50 transition-all hover:shadow-lg"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {card.title}
                </CardTitle>
                <div className={`rounded-lg p-2 ${card.bgColor}`}>
                  <card.icon className={`h-4 w-4 ${card.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoading ? (
                    <div className="h-9 w-16 animate-pulse rounded bg-muted" />
                  ) : (
                    card.value
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <a
                href="/dashboard/companies"
                className="flex items-center justify-between rounded-lg border p-4 transition-all hover:bg-accent"
              >
                <div className="flex items-center gap-3">
                  <Building2 className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Manage Companies</p>
                    <p className="text-sm text-muted-foreground">
                      Add, edit, or remove companies
                    </p>
                  </div>
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
              </a>
              <a
                href="/dashboard/admins"
                className="flex items-center justify-between rounded-lg border p-4 transition-all hover:bg-accent"
              >
                <div className="flex items-center gap-3">
                  <Users className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Manage Admins</p>
                    <p className="text-sm text-muted-foreground">
                      View and manage admin users
                    </p>
                  </div>
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
              </a>
              
              <a
                href="/dashboard/schedules"
                target="_blank"
                className="flex items-center justify-between rounded-lg border p-4 transition-all hover:bg-accent"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/10">
                    <FolderOpen className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="font-medium">Schedules Manager</p>
                    <p className="text-sm text-muted-foreground">
                      Manage Schedules
                    </p>
                  </div>
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
              </a>
            </CardContent>
          </Card>

          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-warning" />
                Webhook Forms
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <a
                href="/dashboard/queries"
                target=""
                className="flex items-center justify-between rounded-lg border p-4 transition-all hover:bg-accent"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <MessageSquare className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Query Submission Form</p>
                    <p className="text-sm text-muted-foreground">
                      Public form for user queries
                    </p>
                  </div>
                </div>
                <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
              </a>
              
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
